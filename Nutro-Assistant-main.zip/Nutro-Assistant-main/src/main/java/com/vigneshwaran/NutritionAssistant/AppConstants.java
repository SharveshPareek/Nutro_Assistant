package com.vigneshwaran.NutritionAssistant;

import org.springframework.beans.factory.annotation.Value;

public class AppConstants {
	
	public static final String API_KEY="";
}
